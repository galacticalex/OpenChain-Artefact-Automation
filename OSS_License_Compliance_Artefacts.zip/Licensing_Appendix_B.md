# Appendix B: Notices and Attribution

---------------

File: OpenBLAS/benchmark/amax.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/amin.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/asum.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/axpby.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/axpy.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/cholesky.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/benchmark/copy.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/dot.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/geev.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/benchmark/gemm.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/gemm3m.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/gemv.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/ger.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/gesv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/benchmark/getri.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/benchmark/hbmv.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/hemm.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/hemv.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/her.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/her2.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/her2k.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/herk.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/hpmv.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/iamax.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/iamin.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/imax.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/imin.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/linpack.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/benchmark/max.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/min.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/nrm2.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/plot-filter.sh
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/plot-header
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/potrf.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/benchmark/rot.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/rotm.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/scal.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/spmv.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/spr.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/spr2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/swap.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/symm.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/symv.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/syr.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/syr2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/syr2k.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/syrk.c
Copyright statement(s): Copyright (c) 2014, 2023 The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/tplot-header
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/tpmv.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/tpsv.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/trmm.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/trmv.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/trsm.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/trsv.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/zdot-intel.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/benchmark/zdot.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/cmake/f_check.cmake
Copyright statement(s): Copyright (c) Stat-Ease, Inc.

---------------

File: OpenBLAS/common_alpha.h
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/common_arm.h
Copyright statement(s): Copyright (c) 2011-2015, The OpenBLAS Project

---------------

File: OpenBLAS/common_arm64.h
Copyright statement(s): Copyright (c) 2011-2015, The OpenBLAS Project

---------------

File: OpenBLAS/common_e2k.h
Copyright statement(s): Copyright (c) 2011-2016, The OpenBLAS Project

---------------

File: OpenBLAS/common_ia64.h
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/common_interface.h
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/common_lapack.h
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/common_level1.h
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/common_level2.h
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/common_level3.h
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/common_linux.h
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/common_loongarch64.h
Copyright statement(s): c("Copyright (c) 2011-2020, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/common_macro.h
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/common_mips.h
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/common_mips64.h
Copyright statement(s): c("Copyright (c) 2011-2014, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/common_param.h
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/common_power.h
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/common_reference.h
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/common_riscv64.h
Copyright statement(s): c("Copyright (c) 2011-2014, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/common_sparc.h
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/common_stackalloc.h
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/common_thread.h
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/common_x86_64.h
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/common_x86.h
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/common_zarch.h
Copyright statement(s): Copyright (c) 2011-2016, The OpenBLAS Project

---------------

File: OpenBLAS/common.h
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/cpuid_alpha.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/cpuid_arm.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/cpuid_arm64.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/cpuid_ia64.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/cpuid_loongarch64.c
Copyright statement(s): Copyright (c) 2011-2020, The OpenBLAS Project

---------------

File: OpenBLAS/cpuid_mips.c
Copyright statement(s): c("Copyright (c) 2011-2014, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/cpuid_mips64.c
Copyright statement(s): c("Copyright (c) 2011-2014, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/cpuid_power.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/cpuid_riscv64.c
Copyright statement(s): c("Copyright (c) 2011-2022, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/cpuid_sparc.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/cpuid_x86.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/cpuid_zarch.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/cpuid.h
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/cpuid.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/ctest/LICENSE
Copyright statement(s): character(0)

---------------

File: OpenBLAS/driver/level2/gbmv_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/gbmv_thread.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/gemv_thread.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/ger_thread.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/sbgemv_thread.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/sbmv_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/sbmv_thread.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/spmv_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/spmv_thread.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/spr_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/spr_thread.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/spr2_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/spr2_thread.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/symv_thread.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/syr_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/syr_thread.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/syr2_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/syr2_thread.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/tbmv_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/tbmv_thread.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/tbmv_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/tbsv_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/tbsv_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/tpmv_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/tpmv_thread.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/tpmv_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/tpsv_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/tpsv_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/trmv_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/trmv_thread.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/trmv_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/trsv_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/trsv_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/zgbmv_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/zhbmv_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/zher_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/zher2_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/zhpmv_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/zhpr_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/zhpr2_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/zsbmv_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/zspmv_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/zspr_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/zspr2_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/zsyr_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/zsyr2_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/ztbmv_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/ztbmv_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/ztbsv_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/ztbsv_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/ztpmv_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/ztpmv_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/ztpsv_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/ztpsv_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/ztrmv_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/ztrmv_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/ztrsv_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level2/ztrsv_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/gemm_thread_m.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/gemm_thread_mn.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/gemm_thread_n.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/gemm_thread_variable.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/gemm.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/gemm3m_level3.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/gemm3m.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/hemm3m_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/level3_gemm3m_thread.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/driver/level3/level3_syr2k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/level3_syrk_threaded.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/driver/level3/level3_syrk.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/level3_thread.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/driver/level3/level3.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/symm_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/symm3m_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/syr2k_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/syr2k_kernel.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/syrk_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/syrk_kernel.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/syrk_thread.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/trmm_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/trmm_R.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/trsm_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/trsm_R.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/zhemm_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/zher2k_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/zher2k_kernel.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/zherk_beta.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/zherk_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/zherk_kernel.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/level3/zsyrk_beta.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/mapper/mapper.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/others/abs.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/others/blas_l1_thread.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/others/blas_server_omp.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/others/blas_server_win32.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/others/blas_server.c
Copyright statement(s): c("Copyright (c) 2011-2014, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/driver/others/divtable.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/others/dynamic_arm64.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/driver/others/dynamic_loongarch64.c
Copyright statement(s): Copyright (c) 2022, The OpenBLAS Project

---------------

File: OpenBLAS/driver/others/dynamic_mips64.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/driver/others/dynamic.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/others/init.c
Copyright statement(s): c("Copyright (c) 2011-2014, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/driver/others/lamc3.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/others/lamch.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/others/lsame.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/others/memory_qalloc.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/others/memory.c
Copyright statement(s): c("Copyright (c) 2011-2014, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/driver/others/openblas_env.c
Copyright statement(s): Copyright (c) 2011-2016, The OpenBLAS Project

---------------

File: OpenBLAS/driver/others/openblas_error_handle.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/driver/others/openblas_get_config.c
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/driver/others/openblas_get_num_procs.c
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/driver/others/openblas_get_num_threads.c
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/driver/others/openblas_get_parallel.c
Copyright statement(s): Copyright (c) 2013 Martin Koehler, grisuthedragon@users.github.com

---------------

File: OpenBLAS/driver/others/openblas_set_num_threads.c
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/driver/others/parameter.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/others/profile.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/driver/others/xerbla.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/exports/dllinit.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/getarch.c
Copyright statement(s): c("Copyright (c) 2011-2014, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/GotoBLAS_00License.txt
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/asum.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/axpby.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/interface/axpy.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/copy.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/dot.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/dsdot.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/gbmv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/geadd.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/gemm.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/gemmt.c
Copyright statement(s): Copyright 2022, The OpenBLAS Project

---------------

File: OpenBLAS/interface/gemv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/ger.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/imatcopy.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/interface/imax.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/fortran/dlaqr5.f
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/interface/lapack/gesv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/getf2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/getrf.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/getrs.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/larf.c.obsolete
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/laswp.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/lauu2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/lauum.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/potf2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/potrf.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/potri.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/trti2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/trtri.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/trtrs.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/zgetf2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/zgetrf.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/zgetrs.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/zlaswp.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/zlauu2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/zlauum.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/zpotf2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/zpotrf.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/zpotri.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/ztrti2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/ztrtri.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/lapack/ztrtrs.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/max.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/nrm2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/omatcopy.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/interface/rot.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/rotmg.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/interface/sbgemv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/sbmv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/scal.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/sdsdot.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/spmv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/spr.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/spr2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/sum.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/swap.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/symm.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/symv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/syr.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/syr2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/syr2k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/syrk.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/tbmv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/tbsv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/tpmv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/tpsv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/trmv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/trsm.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/trsv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zaxpby.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/interface/zaxpy.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zdot.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zgbmv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zgeadd.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zgemv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zger.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zhbmv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zhemv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zher.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zher2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zhpmv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zhpr.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zhpr2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zimatcopy.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/interface/zomatcopy.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/interface/zrot.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zsbmv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zscal.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zspmv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zspr.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zspr2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zswap.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zsymv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zsyr.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/zsyr2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/ztbmv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/ztbsv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/ztpmv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/ztpsv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/ztrmv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/interface/ztrsv.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/amax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/asum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/axpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/cabs.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/cnrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/copy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/cscal.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/dnrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/dot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/gemm_beta.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/gemm_kernel_4x4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/gemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/gemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/iamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/imax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/izamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/lsame.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/max.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/rot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/scal.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/snrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/staticbuffer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/sum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/swap.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/trsm_kernel_4x4_LN.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/trsm_kernel_4x4_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/trsm_kernel_4x4_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/zamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/zasum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/zaxpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/zdot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/zgemm_beta.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/zgemm_kernel_2x2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/zgemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/zgemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/znrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/zrot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/zscal.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/zsum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/zswap.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/ztrsm_kernel_2x2_LN.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/ztrsm_kernel_2x2_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/alpha/ztrsm_kernel_2x2_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/arm/amax_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/amax.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/amin.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/asum_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/asum.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/axpby.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/axpy_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/axpy.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/ccopy_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/cdot_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/cgemm_kernel_2x2_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/cgemm_kernel_2x2_vfpv3.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/cgemm_ncopy_2_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/cgemm_tcopy_2_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/cgemv_n_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/cgemv_t_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/copy.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/ctrmm_kernel_2x2_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/ctrmm_kernel_2x2_vfpv3.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/dcopy_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/ddot_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/dgemm_kernel_4x2_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/dgemm_kernel_4x4_vfpv3.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/dgemm_ncopy_2_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/dgemm_ncopy_4_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/dgemm_tcopy_4_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/dot.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/dtrmm_kernel_4x2_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/dtrmm_kernel_4x4_vfpv3.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/gemv_n_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/gemv_n_vfpv3.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/gemv_n.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/gemv_t_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/gemv_t_vfpv3.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/gemv_t.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/iamax_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/iamax.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/iamin.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/imax.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/imin.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/izamax.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/izamin.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/max.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/min.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/nrm2_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/nrm2_vfpv3.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/nrm2.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/omatcopy_cn.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/omatcopy_ct.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/omatcopy_rn.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/omatcopy_rt.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/rot_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/rot.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/scal_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/scal.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/scopy_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/sdot_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/sgemm_kernel_4x2_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/sgemm_kernel_4x4_vfpv3.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/sgemm_ncopy_2_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/sgemm_ncopy_4_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/sgemm_tcopy_4_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/strmm_kernel_4x2_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/strmm_kernel_4x4_vfpv3.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/sum_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/sum.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/swap_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/swap.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/symv_L.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/symv_U.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zamax.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zamin.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zasum.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zaxpby.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zaxpy.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zcopy_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zcopy.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zdot_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zdot.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zgemm_kernel_2x2_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zgemm_kernel_2x2_vfpv3.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zgemm_ncopy_2_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zgemm_tcopy_2_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zgemv_n_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zgemv_n.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zgemv_t_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zgemv_t.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/znrm2.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zomatcopy_cn.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zomatcopy_cnc.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zomatcopy_ct.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zomatcopy_ctc.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zomatcopy_rn.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zomatcopy_rnc.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zomatcopy_rt.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zomatcopy_rtc.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zrot.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zscal.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zsum.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/zswap.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/ztrmm_kernel_2x2_vfp.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm/ztrmm_kernel_2x2_vfpv3.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/amax.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/asum.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/axpy.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/casum_thunderx2t99.c
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/casum.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/cgemm_kernel_4x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/cgemm_kernel_8x4_cortexa53.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/cgemm_kernel_8x4_thunderx2t99.S
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/cgemm_kernel_8x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/cgemm_kernel_sve_v1x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/cgemm_ncopy_sve_v1.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/cgemm_tcopy_sve_v1.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/copy_thunderx2t99.c
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/copy.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/csum.S
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/ctrmm_kernel_4x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/ctrmm_kernel_8x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/ctrmm_kernel_sve_v1x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dasum_thunderx2t99.c
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/daxpy_thunderx.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/daxpy_thunderx2t99.S
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/ddot_thunderx.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dgemm_beta.S
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dgemm_kernel_4x4_cortexa53.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dgemm_kernel_4x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dgemm_kernel_4x8.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dgemm_kernel_8x4_thunderx2t99.S
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dgemm_kernel_8x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dgemm_kernel_sve_v1x8.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dgemm_kernel_sve_v2x8.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dgemm_ncopy_4.S
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dgemm_ncopy_8.S
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dgemm_tcopy_4.S
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dgemm_tcopy_8.S
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dot_kernel_asimd.c
Copyright statement(s): c("Copyright (c) 2017, The OpenBLAS Project", "Copyright (c) 2022, Arm Ltd")

---------------

File: OpenBLAS/kernel/arm64/dot_kernel_sve.c
Copyright statement(s): Copyright (c) 2022, Arm Ltd

---------------

File: OpenBLAS/kernel/arm64/dot_thunderx.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dot.c
Copyright statement(s): c("Copyright (c) 2017, The OpenBLAS Project", "Copyright (c) 2022, Arm Ltd")

---------------

File: OpenBLAS/kernel/arm64/dot.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dtrmm_kernel_4x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dtrmm_kernel_4x8.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dtrmm_kernel_8x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dtrmm_kernel_sve_v1x8.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dznrm2_thunderx2t99_fast.c
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/dznrm2_thunderx2t99.c
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/gemm_ncopy_complex_sve_v1x4.c
Copyright statement(s): Copyright (c) 2023, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/gemm_ncopy_sve_v1x8.c
Copyright statement(s): Copyright (c) 2023, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/gemm_tcopy_complex_sve_v1x4.c
Copyright statement(s): Copyright (c) 2023, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/gemm_tcopy_sve_v1x8.c
Copyright statement(s): Copyright (c) 2023, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/gemv_n.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/gemv_t.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/iamax_thunderx2t99.c
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/iamax.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/izamax_thunderx2t99.c
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/izamax.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/nrm2.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/rot.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sasum_thunderx2t99.c
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sbgemm_beta_neoversen2.c
Copyright statement(s): Copyright (c) 2022, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sbgemm_kernel_8x4_neoversen2_impl.c
Copyright statement(s): Copyright (c) 2022, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sbgemm_kernel_8x4_neoversen2.c
Copyright statement(s): Copyright (c) 2022, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sbgemm_ncopy_4_neoversen2.c
Copyright statement(s): Copyright (c) 2022, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sbgemm_ncopy_8_neoversen2.c
Copyright statement(s): Copyright (c) 2022, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sbgemm_tcopy_4_neoversen2.c
Copyright statement(s): Copyright (c) 2022, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sbgemm_tcopy_8_neoversen2.c
Copyright statement(s): Copyright (c) 2022, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/scal.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/scnrm2_thunderx2t99.c
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sgemm_beta.S
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sgemm_kernel_16x4_thunderx2t99.S
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sgemm_kernel_16x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sgemm_kernel_4x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sgemm_kernel_8x8_cortexa53.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sgemm_kernel_8x8.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sgemm_kernel_sve_v1x8.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sgemm_kernel_sve_v2x8.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sgemm_ncopy_4.S
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sgemm_ncopy_8.S
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sgemm_tcopy_16.S
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sgemm_tcopy_8.S
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/strmm_kernel_16x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/strmm_kernel_4x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/strmm_kernel_8x8_cortexa53.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/strmm_kernel_8x8.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/strmm_kernel_sve_v1x8.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/sum.S
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/swap_thunderx2t99.S
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/swap.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/symm_lcopy_sve.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/symm_ucopy_sve.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/trmm_lncopy_sve_v1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/arm64/trmm_ltcopy_sve_v1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/arm64/trmm_uncopy_sve_v1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/arm64/trmm_utcopy_sve_v1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/arm64/trsm_kernel_LN_sve.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/arm64/trsm_kernel_LT_sve.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/arm64/trsm_kernel_RN_sve.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/arm64/trsm_kernel_RT_sve.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/arm64/trsm_lncopy_sve.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/arm64/trsm_ltcopy_sve.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/trsm_uncopy_sve.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/trsm_utcopy_sve.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/zamax.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/zasum_thunderx2t99.c
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/zasum.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/zaxpy.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/zdot_thunderx2t99.c
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/zdot.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/zgemm_kernel_4x4_cortexa53.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/zgemm_kernel_4x4_thunderx2t99.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/zgemm_kernel_4x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/zgemm_kernel_sve_v1x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/zgemm_ncopy_sve_v1.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/zgemm_tcopy_sve_v1.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/zgemv_n.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/zgemv_t.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/zhemm_ltcopy_sve.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/zhemm_utcopy_sve.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/znrm2.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/zrot.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/zscal.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/zsum.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/zsymm_lcopy_sve.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/zsymm_ucopy_sve.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/ztrmm_kernel_4x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/ztrmm_kernel_sve_v1x4.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/arm64/ztrmm_lncopy_sve_v1.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/ztrmm_ltcopy_sve_v1.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/ztrmm_uncopy_sve_v1.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/ztrmm_utcopy_sve_v1.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/ztrsm_lncopy_sve.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/ztrsm_ltcopy_sve.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/ztrsm_uncopy_sve.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/arm64/ztrsm_utcopy_sve.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/generic/cabs.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/dot.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/geadd.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/gemm_beta.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/gemm_ncopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/gemm_ncopy_16.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/gemm_ncopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/gemm_ncopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/gemm_ncopy_6.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/gemm_ncopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/gemm_small_matrix_kernel_nn.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/gemm_small_matrix_kernel_nt.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/gemm_small_matrix_kernel_tn.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/gemm_small_matrix_kernel_tt.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/gemm_small_matrix_permit.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/gemm_tcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/gemm_tcopy_16.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/gemm_tcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/gemm_tcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/gemm_tcopy_6.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/gemm_tcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ger.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/imatcopy_cn.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/imatcopy_ct.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/imatcopy_rn.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/imatcopy_rt.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/laswp_ncopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/laswp_ncopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/laswp_ncopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/laswp_ncopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/lsame.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/neg_tcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/neg_tcopy_16.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/neg_tcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/neg_tcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/neg_tcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/symm_lcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/symm_lcopy_16.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/symm_lcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/symm_lcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/symm_lcopy_6.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/symm_lcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/symm_ucopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/symm_ucopy_16.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/symm_ucopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/symm_ucopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/symm_ucopy_6.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/symm_ucopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/symv_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_lncopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_lncopy_16.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_lncopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_lncopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_lncopy_6.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_lncopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_ltcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_ltcopy_16.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_ltcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_ltcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_ltcopy_6.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_ltcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_uncopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_uncopy_16.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_uncopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_uncopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_uncopy_6.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_uncopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_utcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_utcopy_16.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_utcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_utcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_utcopy_6.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trmm_utcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_kernel_LN.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_kernel_LT.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_kernel_RN.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_kernel_RT.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_lncopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_lncopy_16.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_lncopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_lncopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_lncopy_6.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_lncopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_ltcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_ltcopy_16.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_ltcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_ltcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_ltcopy_6.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_ltcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_uncopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_uncopy_16.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_uncopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_uncopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_uncopy_6.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_uncopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_utcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_utcopy_16.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_utcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_utcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_utcopy_6.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/trsm_utcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgeadd.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zgemm_beta.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgemm_ncopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgemm_ncopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgemm_ncopy_4_sandy.c
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zgemm_ncopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgemm_ncopy_8_sandy.c
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zgemm_ncopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgemm_small_matrix_kernel_nn.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zgemm_small_matrix_kernel_nt.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zgemm_small_matrix_kernel_tn.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zgemm_small_matrix_kernel_tt.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zgemm_small_matrix_permit.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zgemm_tcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgemm_tcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgemm_tcopy_4_sandy.c
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zgemm_tcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgemm_tcopy_8_sandy.c
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zgemm_tcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgemm3m_ncopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgemm3m_ncopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgemm3m_ncopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgemm3m_ncopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgemm3m_tcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgemm3m_tcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgemm3m_tcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgemm3m_tcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zgemm3mkernel_dump.c
Copyright statement(s): Copyright (c) 2011-2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zger.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zhemm_ltcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zhemm_ltcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zhemm_ltcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zhemm_ltcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zhemm_utcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zhemm_utcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zhemm_utcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zhemm_utcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zhemm3m_lcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zhemm3m_lcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zhemm3m_lcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zhemm3m_lcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zhemm3m_ucopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zhemm3m_ucopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zhemm3m_ucopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zhemm3m_ucopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zhemv_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zimatcopy_cn.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zimatcopy_cnc.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zimatcopy_ct.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zimatcopy_ctc.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zimatcopy_rn.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zimatcopy_rnc.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zimatcopy_rt.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zimatcopy_rtc.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/generic/zlaswp_ncopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zlaswp_ncopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zlaswp_ncopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zneg_tcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zneg_tcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zneg_tcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zneg_tcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zsymm_lcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zsymm_lcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zsymm_lcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zsymm_lcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zsymm_ucopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zsymm_ucopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zsymm_ucopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zsymm_ucopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zsymm3m_lcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zsymm3m_lcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zsymm3m_lcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zsymm3m_lcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zsymm3m_ucopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zsymm3m_ucopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zsymm3m_ucopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zsymm3m_ucopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/zsymv_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrmm_lncopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrmm_lncopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrmm_lncopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrmm_lncopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrmm_ltcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrmm_ltcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrmm_ltcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrmm_ltcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrmm_uncopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrmm_uncopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrmm_uncopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrmm_uncopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrmm_utcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrmm_utcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrmm_utcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrmm_utcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrsm_lncopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrsm_lncopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrsm_lncopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrsm_lncopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrsm_ltcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrsm_ltcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrsm_ltcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrsm_ltcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrsm_uncopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrsm_uncopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrsm_uncopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrsm_uncopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrsm_utcopy_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrsm_utcopy_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrsm_utcopy_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/generic/ztrsm_utcopy_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/amax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/asum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/cabs.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/caxpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/copy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/daxpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/ddot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/gemm_beta.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/gemm_kernel.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/gemm_ncopy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/gemm_tcopy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/gemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/gemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/iamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/izamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/lsame.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/nrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/qaxpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/qcopy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/qdot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/qgemm_kernel.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/qgemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/qgemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/qscal.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/rot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/saxpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/scal.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/sdot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/sgemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/staticbuffer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/sum.S
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2019, The OpenBLAS project")

---------------

File: OpenBLAS/kernel/ia64/swap.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/symv_U.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/trsm_kernel_LN.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/trsm_kernel_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/trsm_kernel_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/xcopy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/xdot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/zaxpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/zcopy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/zdot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/zgemm_beta.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/zgemm_kernel.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/zgemm_ncopy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/zgemm_tcopy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/zgemm3m_kernel.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/zgemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/zgemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/zrot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/zscal.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/zswap.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/ztrsm_kernel_LN.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/ztrsm_kernel_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/ia64/ztrsm_kernel_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/loongarch64/amax.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/amin.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/asum.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/cnrm2.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/copy.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/dgemm_kernel_16x4.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/dgemm_ncopy_16.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/dgemm_ncopy_4.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/dgemm_tcopy_16.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/dgemm_tcopy_4.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/dgemv_n_8_lasx.S
Copyright statement(s): Copyright (c) 2023, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/dgemv_t_8_lasx.S
Copyright statement(s): Copyright (c) 2023, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/dnrm2.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/dot.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/gemm_kernel.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/gemv_n.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/gemv_t.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/iamax.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/iamin.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/izamax.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/izamin.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/loongarch64_asm.S
Copyright statement(s): Copyright (c) 2023, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/max.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/min.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/scal.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/sgemm_kernel_16x8_lasx.S
Copyright statement(s): Copyright (c) 2023, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/sgemm_ncopy_16_lasx.S
Copyright statement(s): Copyright (c) 2023, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/sgemm_ncopy_8_lasx.S
Copyright statement(s): Copyright (c) 2023, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/sgemm_tcopy_16_lasx.S
Copyright statement(s): Copyright (c) 2023, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/sgemm_tcopy_8_lasx.S
Copyright statement(s): Copyright (c) 2023, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/snrm2.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/swap.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/trsm_kernel_LN.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/trsm_kernel_LT.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/trsm_kernel_RT.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/zamax.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/zamin.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/zasum.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/zcopy.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/zdot.S
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/zgemm_kernel.S
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/zgemm3m_kernel.S
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/zgemv_n.S
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/zgemv_t.S
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/znrm2.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/zscal.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/ztrsm_kernel_LT.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/loongarch64/ztrsm_kernel_RT.S
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/amax.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/amin.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/asum.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/axpby.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/axpy.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/casum_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/caxpy_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/ccopy_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/cdot_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/cgemm_kernel_8x4_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/cgemm_ncopy_4_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/cgemm_ncopy_8_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/cgemm_tcopy_4_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/cgemm_tcopy_8_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/cgemv_n_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/cgemv_t_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/copy.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/crot_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/cscal_msa.c
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/cswap_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/dasum_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/daxpy_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/dcopy_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/ddot_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/dgemm_kernel_8x4_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/dgemm_ncopy_4_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/dgemm_ncopy_8_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/dgemm_tcopy_4_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/dgemm_tcopy_8_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/dgemv_n_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/dgemv_t_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/dot.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/drot_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/dscal_msa.c
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/dswap_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/dtrsm_kernel_LN_8x4_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/dtrsm_kernel_LT_8x4_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/dtrsm_kernel_RN_8x4_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/dtrsm_kernel_RT_8x4_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/gemv_n.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/gemv_t.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/iamax.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/iamin.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/imax.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/imin.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/izamax.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/izamin.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/macros_msa.h
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/max.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/min.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/nrm2.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/omatcopy_cn.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/omatcopy_ct.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/omatcopy_rn.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/omatcopy_rt.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/rot.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/sasum_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/saxpy_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/scal.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/scopy_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/sdot_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/sgemm_kernel_8x8_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/sgemm_ncopy_8_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/sgemm_tcopy_8_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/sgemv_n_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/sgemv_t_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/srot_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/sscal_msa.c
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/sswap_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/strsm_kernel_LN_8x8_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/strsm_kernel_LT_8x8_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/strsm_kernel_RN_8x8_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/strsm_kernel_RT_8x8_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/sum.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/swap.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/symv_L.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/symv_U.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zamax.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zamin.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zasum_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zasum.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zaxpby.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zaxpy_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zaxpy.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zcopy_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zcopy.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zdot_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zdot.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zgemm_kernel_4x4_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zgemm_ncopy_4_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zgemm_tcopy_4_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zgemv_n_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zgemv_n.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zgemv_t_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zgemv_t.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/znrm2.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zomatcopy_cn.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zomatcopy_cnc.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zomatcopy_ct.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zomatcopy_ctc.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zomatcopy_rn.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zomatcopy_rnc.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zomatcopy_rt.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zomatcopy_rtc.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zrot_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zrot.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zscal_msa.c
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zscal.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zsum.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zswap_msa.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips/zswap.c
Copyright statement(s): Copyright (c) 2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/mips64/amax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/amin.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/asum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/axpy_loongson3a.S
Copyright statement(s): c("Copyright (c) 2011-2014, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/mips64/axpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/cnrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/copy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/daxpy_loongson3a_simd.S
Copyright statement(s): c("Copyright (c) 2011-2014, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/mips64/dnrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/dot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/gemm_beta.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/gemm_kernel.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/gemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/gemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/iamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/iamin.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/imax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/imin.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/izamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/izamin.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/max.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/min.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/rot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/scal.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/sgemm_kernel_8x4_ps.S
Copyright statement(s): c("(c) LD A2", "(c) LD A3", "(c) LD A4", "(c) LD A5", "(c) LD A6", "(c) LD A7", "(c) LD A8", "(c) ST A2", "(c) ST A3", "(c) ST A4", "(c) ST A5", "(c) ST A6", "(c) ST A7", "(c) ST A8", "(c) ST A2", "(c) ST A3", "(c) ST A4", "(c) ST A5", "(c) ST A6", "(c) ST A7", "(c) ST A8", "(c) LD A2", "(c) LD A3", "(c) LD A4", "(c) ST A2", "(c) ST A3", "(c) ST A4", "(c) ST A2", "(c) ST A3", "(c) ST A4", "(c) LD A2", "(c) ST A2", "(c) ST A2")

---------------

File: OpenBLAS/kernel/mips64/snrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/sum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/swap.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/symv_L.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/symv_U.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/trsm_kernel_LN.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/trsm_kernel_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/trsm_kernel_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/zamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/zamin.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/zasum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/zaxpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/zcopy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/zdot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/zgemm_kernel.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/zgemm3m_kernel.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/zgemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/zgemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/znrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/zrot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/zscal.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/zsum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/zswap.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/zsymv_L.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/zsymv_U.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/ztrsm_kernel_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/mips64/ztrsm_kernel_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/amax_cell.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/amax_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/amax_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/amax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/amin_cell.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/amin_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/amin_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/amin.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/asum_cell.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/asum_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/asum_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/asum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/axpy_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/axpy_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/axpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/cabs.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/casum_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/casum.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/caxpy_microk_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/caxpy_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/caxpy.c
Copyright statement(s): Copyright (c) 2013-2018, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/ccopy_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/ccopy_power10.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/ccopy.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cdot_microk_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cdot.c
Copyright statement(s): Copyright (c) 2013-201 8, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cgemm_kernel_8x4_power8.S
Copyright statement(s): c("Copyright (c) 2013-2016, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/power/cgemm_kernel_power10.S
Copyright statement(s): Copyright (c) 2013-2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cgemm_kernel_power9.S
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cgemm_logic_8x4_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cgemm_logic_power10.S
Copyright statement(s): Copyright (c) 2013-2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cgemm_logic_power9.S
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cgemm_macros_8x4_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cgemm_macros_power10.S
Copyright statement(s): Copyright (c) 2013-2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cgemm_macros_power9.S
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cgemm_tcopy_8_power8.S
Copyright statement(s): c("Copyright (c) 2013-2016, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/power/cgemm_tcopy_logic_8_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cgemm_tcopy_macros_8_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cgemv_n.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cgemv_t.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cnrm2_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/cnrm2_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/cnrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/copy_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/copy_microk_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/copy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/crot.c
Copyright statement(s): Copyright (c) 2013-2018, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cscal_microk_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cswap_microk_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cswap_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/cswap.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/ctrmm_kernel_8x4_power8.S
Copyright statement(s): c("Copyright (c) 2013-2016, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/power/ctrmm_logic_8x4_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/ctrmm_macros_8x4_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dasum_microk_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dasum_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dasum.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/daxpy_microk_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/daxpy_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/daxpy_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/daxpy.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dcopy_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dcopy_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dcopy.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/ddot_microk_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/ddot_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/ddot_power10.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/ddot.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemm_kernel_16x4_power8.S
Copyright statement(s): c("Copyright (c) 2013-2016, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/power/dgemm_kernel_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemm_kernel_power9.S
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemm_logic_16x4_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemm_logic_power9.S
Copyright statement(s): Copyright (c) 2013-2019 The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemm_macros_16x4_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemm_macros_power9.S
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemm_ncopy_4_power8.S
Copyright statement(s): c("Copyright (c) 2013-2016, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/power/dgemm_ncopy_8_power10.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/dgemm_ncopy_logic_4_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemm_ncopy_macros_4_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemm_small_kernel_nn_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemm_small_kernel_nt_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemm_small_kernel_tn_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemm_small_kernel_tt_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemm_tcopy_16_power8.S
Copyright statement(s): c("Copyright (c) 2013-2016, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/power/dgemm_tcopy_logic_16_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemm_tcopy_macros_16_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemv_n_microk_power10.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemv_n_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemv_n_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemv_n.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemv_t_power10.c
Copyright statement(s): Copyright (c) 2018, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dgemv_t.c
Copyright statement(s): Copyright (c) 2018, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dnrm2_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/dnrm2_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/dot_cell.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/dot_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/dot_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/dot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/drot_microk_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/drot_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/drot.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dscal_microk_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dscal_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dscal.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dswap_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dswap.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dtrmm_kernel_16x4_power8.S
Copyright statement(s): c("Copyright (c) 2013-2016, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/power/dtrmm_logic_16x4_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dtrmm_macros_16x4_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/dtrsm_kernel_LT_16x4_power8.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/exfunc.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemm_beta.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemm_kernel_altivec_cell.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemm_kernel_altivec_g4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemm_kernel_altivec.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemm_kernel_cell.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemm_kernel_g4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemm_kernel_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemm_kernel_power3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemm_kernel_power6.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemm_kernel_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemm_kernel.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemm_ncopy_4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemm_ncopy_hummer_4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemm_ncopy_hummer_8.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemm_small_kernel_permit_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/gemm_tcopy_4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemm_tcopy_hummer_4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemm_tcopy_hummer_8.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemv_hummer_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemv_n_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemv_t_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/gemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/ger.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/iamax_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/iamax_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/iamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/iamin_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/iamin_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/iamin.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/icamax.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/icamin.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/idamax.c
Copyright statement(s): Copyright (c) 2013-2018, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/idamin.c
Copyright statement(s): Copyright (c) 2013-2018, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/imax_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/imax_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/imax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/imin_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/imin_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/imin.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/isamax.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/isamin.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/izamax_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/izamax_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/izamax.c
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/izamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/izamin_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/izamin_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/izamin.c
Copyright statement(s): Copyright (c) 2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/izamin.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/lock.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/lsame.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/max_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/max_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/max.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/min_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/min_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/min.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/nrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/rot_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/rot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/sasum_microk_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sasum_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sasum.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/saxpy_microk_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/saxpy_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/saxpy.c
Copyright statement(s): Copyright (c) 2013-2018, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sbgemm_kernel_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sbgemm_ncopy_16_power10.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/sbgemm_ncopy_8_power10.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/sbgemm_tcopy_16_power10.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/sbgemm_tcopy_8_power10.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/scal_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/scal_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/scal.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/scopy_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/scopy_power10.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/scopy.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sdot_microk_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sdot_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sdot_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sdot.c
Copyright statement(s): Copyright (c) 2013-2017, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sgemm_kernel_16x8_power8.S
Copyright statement(s): c("Copyright (c) 2013-2016, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/power/sgemm_kernel_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sgemm_kernel_power9.S
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sgemm_logic_16x8_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sgemm_macros_16x8_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sgemm_macros_power9.S
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sgemm_small_kernel_nn_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sgemm_small_kernel_nt_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sgemm_small_kernel_tn_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sgemm_small_kernel_tt_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sgemm_tcopy_16_power8.S
Copyright statement(s): c("Copyright (c) 2013-2016, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/power/sgemm_tcopy_8_power8.S
Copyright statement(s): c("Copyright (c) 2013-2016, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/power/sgemm_tcopy_logic_16_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sgemm_tcopy_logic_8_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sgemm_tcopy_macros_16_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sgemm_tcopy_macros_8_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sgemv_n_8.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sgemv_n.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sgemv_t_8.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sgemv_t.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/snrm2_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/snrm2_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/snrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/srot_microk_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/srot_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/srot.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sscal_microk_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sscal_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sscal.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sswap_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sswap.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/staticbuffer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/strmm_kernel_16x8_power8.S
Copyright statement(s): c("Copyright (c) 2013-2016, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/power/strmm_logic_16x8_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/strmm_macros_16x8_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/sum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/swap_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/swap_microk_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/swap.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/symv_L.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/symv_U.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_cell_LN.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_cell_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_cell_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_hummer_LN.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_hummer_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_hummer_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_LN_power10.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_LN.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_LT_power10.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_power6_LN.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_power6_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_power6_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_ppc440_LN.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_ppc440_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_ppc440_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_RN_power10.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_RT_power10.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/trsm_kernel_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zamax_cell.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zamax_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zamax_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zamin_cell.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zamin_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zamin_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zamin.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zasum_cell.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zasum_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zasum_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zasum_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zasum.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zasum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zaxpy_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zaxpy_microk_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zaxpy_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zaxpy_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zaxpy_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zaxpy.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zaxpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zcopy_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zcopy_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zcopy_power10.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zcopy.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zcopy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zdot_cell.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zdot_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zdot_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zdot_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zdot.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zdot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemm_beta.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemm_kernel_8x2_power8.S
Copyright statement(s): c("Copyright (c) 2013-2016, The OpenBLAS Project", "Copyright (c) 2013-2016, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/power/zgemm_kernel_altivec_cell.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemm_kernel_altivec_g4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemm_kernel_altivec.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemm_kernel_cell.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemm_kernel_g4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemm_kernel_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemm_kernel_power10.S
Copyright statement(s): Copyright (c) 2013-2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zgemm_kernel_power3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemm_kernel_power6.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemm_kernel_power9.S
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zgemm_kernel_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemm_kernel.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemm_logic_8x2_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zgemm_logic_power10.S
Copyright statement(s): Copyright (c) 2013-2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zgemm_logic_power9.S
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zgemm_macros_8x2_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zgemm_macros_power10.S
Copyright statement(s): Copyright (c) 2013-2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zgemm_macros_power9.S
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zgemm_ncopy_hummer_2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemm_ncopy_hummer_4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemm_tcopy_8_power8.S
Copyright statement(s): c("Copyright (c) 2013-2016, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/power/zgemm_tcopy_hummer_2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemm_tcopy_hummer_4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemm_tcopy_logic_8_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zgemm_tcopy_macros_8_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zgemv_n_4.c
Copyright statement(s): Copyright (c) 2018, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zgemv_n_power10.c
Copyright statement(s): Copyright (c) 2018, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zgemv_n_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemv_t_4.c
Copyright statement(s): Copyright (c) 2018, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zgemv_t_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zgemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zger.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/znrm2_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/znrm2_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/znrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zrot_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zrot.c
Copyright statement(s): Copyright (c) 2018, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zrot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zscal_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zscal_microk_power10.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zscal_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zscal_ppc440.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zscal.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zscal.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zsum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zswap_hummer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zswap_microk_power8.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zswap.c
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/zswap.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zsymv_L.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/zsymv_U.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/ztrmm_kernel_8x2_power8.S
Copyright statement(s): c("Copyright (c) 2013-2016, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/power/ztrmm_logic_8x2_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/ztrmm_macros_8x2_power8.S
Copyright statement(s): Copyright (c) 2013-2016, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/power/ztrsm_kernel_cell_LN.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/ztrsm_kernel_cell_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/ztrsm_kernel_cell_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/ztrsm_kernel_hummer_LN.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/ztrsm_kernel_hummer_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/ztrsm_kernel_hummer_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/ztrsm_kernel_LN.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/ztrsm_kernel_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/ztrsm_kernel_power6_LN.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/ztrsm_kernel_power6_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/ztrsm_kernel_power6_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/ztrsm_kernel_ppc440_LN.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/ztrsm_kernel_ppc440_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/ztrsm_kernel_ppc440_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/power/ztrsm_kernel_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/riscv64/amax_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/amax.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/amin_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/amin.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/asum_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/asum.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/axpby_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/axpby.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/axpy_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/axpy.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/copy_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/copy.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/dot_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/dot.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/gemv_n_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/gemv_n.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/gemv_t_vector.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/gemv_t.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/iamax_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/iamax.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/iamin_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/iamin.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/imax_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/imax.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/imin_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/imin.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/izamax_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/izamax.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/izamin_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/izamin.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/max_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/max.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/min_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/min.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/nrm2_vector_dot.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/nrm2_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/nrm2.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/omatcopy_cn.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/omatcopy_ct.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/omatcopy_rn.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/omatcopy_rt.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/rot_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/rot.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/scal_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/scal.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/swap_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/swap.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/symv_L_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/symv_L.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/symv_U_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/symv_U.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zamax_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zamax.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zamin_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zamin.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zasum_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zasum.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zaxpby_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zaxpby.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zaxpy_vector.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zaxpy.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zcopy_vector.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zcopy.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zdot_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zdot.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zgemv_n_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zgemv_n.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zgemv_t_vector.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zgemv_t.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zhemv_LM_vector.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zhemv_UV_vector.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/znrm2_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/znrm2.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zomatcopy_cn.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zomatcopy_cnc.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zomatcopy_ct.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zomatcopy_ctc.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zomatcopy_rn.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zomatcopy_rnc.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zomatcopy_rt.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zomatcopy_rtc.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zrot_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zrot.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zscal_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zscal.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zswap_vector.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/riscv64/zswap.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/setparam-ref.c
Copyright statement(s): c("Copyright 2009, 2010 The University of Texas at Austin", "Copyright 2023 The OpenBLAS Project")

---------------

File: OpenBLAS/kernel/sparc/amax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/asum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/axpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/cabs.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/cnrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/copy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/dnrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/dot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/gemm_kernel_2x8.S
Copyright statement(s): Copyright 2005-2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/gemm_kernel.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/gemm_ncopy_2.S
Copyright statement(s): Copyright 2005-2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/gemm_ncopy_8.S
Copyright statement(s): Copyright 2005-2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/gemm_ncopy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/gemm_tcopy_2.S
Copyright statement(s): Copyright 2005-2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/gemm_tcopy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/gemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/gemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/ger.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/iamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/imax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/izamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/lsame.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/max.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/rot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/scal.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/snrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/staticbuffer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/sum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/swap.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/trsm_kernel_LN_2x8.S
Copyright statement(s): Copyright 2005-2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/trsm_kernel_LN.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/trsm_kernel_LT_2x8.S
Copyright statement(s): Copyright 2005-2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/trsm_kernel_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/trsm_kernel_RT_2x8.S
Copyright statement(s): Copyright 2005-2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/trsm_kernel_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/zamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/zasum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/zaxpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/zcopy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/zdot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/zgemm_kernel_1x4.S
Copyright statement(s): Copyright 2005-2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/zgemm_kernel.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/zgemm_ncopy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/zgemm_tcopy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/zgemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/zgemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/znrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/zrot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/zscal.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/zsum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/zswap.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/ztrsm_kernel_LN.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/ztrsm_kernel_LT_1x4.S
Copyright statement(s): Copyright 2005-2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/ztrsm_kernel_LT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/ztrsm_kernel_RT_1x4.S
Copyright statement(s): Copyright 2005-2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/sparc/ztrsm_kernel_RT.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/amax_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/amax_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/amax_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/amax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/asum_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/asum_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/asum_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/asum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/axpy_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/axpy_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/axpy_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/axpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/bf16_common_macros.h
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/bf16to.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/builtin_stinit.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/cabs.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/caxpy_microk_bulldozer-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/caxpy_microk_haswell-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/caxpy_microk_sandy-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/caxpy_microk_steamroller-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/caxpy.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cdot_microk_bulldozer-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cdot_microk_haswell-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cdot_microk_sandy-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cdot_microk_steamroller-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cdot.c
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cgemm_kernel_4x2_bulldozer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/cgemm_kernel_4x2_piledriver.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cgemm_kernel_4x8_sandy.S
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cgemm_kernel_8x2_haswell.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cgemm_kernel_8x2_sandy.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cgemv_n_4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cgemv_n_microk_bulldozer-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cgemv_n_microk_haswell-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cgemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/cgemv_t_4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cgemv_t_microk_bulldozer-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cgemv_t_microk_haswell-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cgemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/copy_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/copy_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/copy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/cscal_microk_bulldozer-2.c
Copyright statement(s): Copyright (c) 2014-2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cscal_microk_haswell-2.c
Copyright statement(s): Copyright (c) 2014-2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cscal_microk_skylakex-2.c
Copyright statement(s): Copyright (c) 2014-2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cscal_microk_steamroller-2.c
Copyright statement(s): Copyright (c) 2014-2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/cscal.c
Copyright statement(s): Copyright (c) 2013 - 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ctrsm_kernel_LN_bulldozer.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ctrsm_kernel_LT_bulldozer.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ctrsm_kernel_RN_bulldozer.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ctrsm_kernel_RT_bulldozer.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/daxpy_bulldozer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/daxpy_microk_bulldozer-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/daxpy_microk_haswell-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/daxpy_microk_nehalem-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/daxpy_microk_piledriver-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/daxpy_microk_sandy-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/daxpy_microk_skylakex-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/daxpy_microk_steamroller-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/daxpy.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dcopy_bulldozer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ddot_bulldozer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ddot_microk_bulldozer-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ddot_microk_haswell-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ddot_microk_nehalem-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ddot_microk_piledriver-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ddot_microk_sandy-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ddot_microk_skylakex-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ddot_microk_steamroller-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ddot.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemm_beta_skylakex.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemm_kernel_16x2_haswell.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemm_kernel_16x2_skylakex.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemm_kernel_4x4_haswell.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemm_kernel_4x8_haswell.S
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemm_kernel_4x8_sandy.S
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemm_kernel_4x8_skylakex.c
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemm_kernel_6x4_piledriver.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemm_kernel_8x2_bulldozer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemm_kernel_8x2_piledriver.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemm_ncopy_2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemm_ncopy_4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemm_ncopy_8_bulldozer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemm_ncopy_8_skylakex.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemm_ncopy_8.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemm_small_kernel_nn_skylakex.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemm_small_kernel_nt_skylakex.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemm_small_kernel_permit_skylakex.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemm_small_kernel_tn_skylakex.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemm_small_kernel_tt_skylakex.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemm_tcopy_2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemm_tcopy_4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemm_tcopy_8_bulldozer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemm_tcopy_8_skylakex.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemm_tcopy_8.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemv_n_4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemv_n_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemv_n_bulldozer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemv_n_microk_haswell-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemv_n_microk_nehalem-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemv_n_microk_piledriver-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemv_n_microk_skylakex-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemv_t_4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemv_t_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemv_t_bulldozer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dgemv_t_microk_haswell-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dgemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dger_microk_sandy-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dger.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dot_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dot_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dot_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dscal_microk_bulldozer-2.c
Copyright statement(s): Copyright (c) 2014-2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dscal_microk_haswell-2.c
Copyright statement(s): Copyright (c) 2014-2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dscal_microk_sandy-2.c
Copyright statement(s): Copyright (c) 2014-2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dscal_microk_skylakex-2.c
Copyright statement(s): Copyright (c) 2014-2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dscal.c
Copyright statement(s): Copyright (c) 2013 - 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dsymv_L_microk_bulldozer-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dsymv_L_microk_haswell-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dsymv_L_microk_nehalem-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dsymv_L_microk_sandy-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dsymv_L_microk_skylakex-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dsymv_L.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dsymv_U_microk_bulldozer-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dsymv_U_microk_haswell-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dsymv_U_microk_nehalem-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dsymv_U_microk_sandy-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dsymv_U.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dtobf16_microk_cooperlake.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/dtrsm_kernel_LN_bulldozer.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dtrsm_kernel_LT_8x2_bulldozer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dtrsm_kernel_RN_8x2_bulldozer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dtrsm_kernel_RN_haswell.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/dtrsm_kernel_RT_bulldozer.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_beta.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_kernel_2x8_nehalem.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_kernel_4x2_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_kernel_4x4_barcelona.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_kernel_4x4_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_kernel_4x4_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_kernel_4x4_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_kernel_4x4_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_kernel_4x8_nano.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_kernel_4x8_nehalem.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_kernel_8x4_barcelona.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_kernel_8x4_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_kernel_8x4_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_kernel_8x4_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_kernel_8x4_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_ncopy_2_bulldozer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_ncopy_2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_ncopy_4_opteron.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_ncopy_4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_tcopy_2_bulldozer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_tcopy_2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_tcopy_4_opteron.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/gemm_tcopy_4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/iamax_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/iamax_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/iamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/izamax_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/izamax_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/izamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/lsame.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/mcount.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/nrm2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/nrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/omatcopy_rt.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/qconjg.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/qdot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/qgemm_kernel_2x2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/qgemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/qgemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/qtrsm_kernel_LN_2x2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/qtrsm_kernel_LT_2x2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/qtrsm_kernel_RT_2x2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/rot_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/rot_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/rot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/saxpy_microk_haswell-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/saxpy_microk_nehalem-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/saxpy_microk_piledriver-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/saxpy_microk_sandy-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/saxpy_microk_skylakex-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/saxpy.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbdot_microk_cooperlake.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbdot.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemm_kernel_16x16_spr_tmpl.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemm_kernel_16x16_spr.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemm_kernel_16x4_cooperlake.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemm_ncopy_16_cooperlake.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemm_ncopy_4_cooperlake.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemm_oncopy_16_spr.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemm_otcopy_16_spr.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemm_small_kernel_permit_cooperlake.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemm_small_kernel_permit_spr.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemm_small_kernel_template_cooperlake.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemm_tcopy_16_cooperlake.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemm_tcopy_4_cooperlake.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemv_n_microk_cooperlake_template.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemv_n_microk_cooperlake.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemv_n.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemv_t_microk_cooperlake_template.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemv_t_microk_cooperlake.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sbgemv_t.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/scal_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/scal_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/scal_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/scal.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/sdot_microk_bulldozer-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sdot_microk_haswell-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sdot_microk_nehalem-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sdot_microk_sandy-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sdot_microk_skylakex-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sdot_microk_steamroller-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sdot.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemm_beta_skylakex.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/sgemm_kernel_16x2_bulldozer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/sgemm_kernel_16x2_piledriver.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemm_kernel_16x4_haswell.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemm_kernel_16x4_sandy.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemm_kernel_16x4_skylakex.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemm_kernel_16x4_skylakex.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemm_kernel_8x4_bulldozer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/sgemm_kernel_8x8_sandy.S
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemm_ncopy_4_skylakex.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/sgemm_small_kernel_nn_skylakex.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemm_small_kernel_nt_skylakex.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemm_small_kernel_permit_skylakex.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemm_small_kernel_tn_skylakex.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemm_small_kernel_tt_skylakex.c
Copyright statement(s): Copyright (c) 2021, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemm_tcopy_16_skylakex.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/sgemv_n_4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemv_n_microk_bulldozer-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemv_n_microk_haswell-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemv_n_microk_nehalem-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemv_n_microk_sandy-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemv_n_microk_skylakex-8.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemv_n.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/sgemv_t_4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemv_t_microk_bulldozer-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemv_t_microk_haswell-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemv_t_microk_nehalem-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemv_t_microk_sandy-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemv_t_microk_skylakex_template.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemv_t_microk_skylakex.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemv_t.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sgemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/sger_microk_sandy-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sger.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/sscal_microk_haswell-2.c
Copyright statement(s): Copyright (c) 2014-2022, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sscal_microk_skylakex-2.c
Copyright statement(s): Copyright (c) 2014-2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/sscal.c
Copyright statement(s): Copyright (c) 2013 - 2022, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ssymv_L_microk_bulldozer-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ssymv_L_microk_haswell-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ssymv_L_microk_nehalem-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ssymv_L_microk_sandy-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ssymv_L.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ssymv_U_microk_bulldozer-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ssymv_U_microk_haswell-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ssymv_U_microk_nehalem-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ssymv_U_microk_sandy-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/ssymv_U.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/staticbuffer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/stobf16_microk_cooperlake.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/strsm_kernel_LN_bulldozer.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/strsm_kernel_LT_bulldozer.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/strsm_kernel_RN_bulldozer.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/strsm_kernel_RT_bulldozer.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/sum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/swap_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/swap_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/swap.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/symv_L_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/symv_L_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/symv_U_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/symv_U_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/tobf16.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LN_2x8_nehalem.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LN_4x2_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LN_4x4_barcelona.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LN_4x4_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LN_4x4_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LN_4x4_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LN_4x4_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LN_4x8_nehalem.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LN_8x4_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LT_2x8_nehalem.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LT_4x2_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LT_4x4_barcelona.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LT_4x4_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LT_4x4_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LT_4x4_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LT_4x4_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LT_4x8_nehalem.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_LT_8x4_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_RT_2x8_nehalem.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_RT_4x2_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_RT_4x4_barcelona.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_RT_4x4_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_RT_4x4_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_RT_4x4_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_RT_4x4_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_RT_4x8_nehalem.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/trsm_kernel_RT_8x4_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/xdot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/xgemm_kernel_1x1.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/xgemm3m_kernel_2x2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/xgemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/xgemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/xtrsm_kernel_LT_1x1.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zamax_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zamax_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zamax_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zasum_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zasum_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zasum_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zasum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zaxpy_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zaxpy_microk_bulldozer-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zaxpy_microk_haswell-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zaxpy_microk_sandy-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zaxpy_microk_steamroller-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zaxpy_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zaxpy_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zaxpy.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zaxpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zcopy_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zcopy_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zcopy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zdot_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zdot_microk_bulldozer-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zdot_microk_haswell-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zdot_microk_sandy-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zdot_microk_steamroller-2.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zdot_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zdot_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zdot.c
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zdot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_beta.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_kernel_1x4_nehalem.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_kernel_2x1_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_kernel_2x2_barcelona.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_kernel_2x2_bulldozer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_kernel_2x2_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_kernel_2x2_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_kernel_2x2_piledriver.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zgemm_kernel_2x2_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_kernel_2x2_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_kernel_2x4_nehalem.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_kernel_4x2_barcelona.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_kernel_4x2_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_kernel_4x2_haswell.S
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zgemm_kernel_4x2_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_kernel_4x2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_kernel_4x2_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_kernel_4x4_sandy.S
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zgemm_ncopy_1.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_ncopy_2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_tcopy_1.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm_tcopy_2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm3m_kernel_2x8_nehalem.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm3m_kernel_4x2_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm3m_kernel_4x4_barcelona.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm3m_kernel_4x4_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm3m_kernel_4x4_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm3m_kernel_4x4_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm3m_kernel_4x4_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm3m_kernel_4x8_nehalem.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm3m_kernel_8x4_barcelona.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm3m_kernel_8x4_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm3m_kernel_8x4_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm3m_kernel_8x4_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemm3m_kernel_8x4_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemv_n_4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zgemv_n_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemv_n_dup.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemv_n_microk_bulldozer-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zgemv_n_microk_haswell-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zgemv_n_microk_sandy-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zgemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemv_t_4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zgemv_t_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemv_t_dup.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zgemv_t_microk_bulldozer-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zgemv_t_microk_haswell-4.c
Copyright statement(s): Copyright (c) 2014, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zgemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/znrm2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/znrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zrot_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zrot_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zrot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zscal_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zscal_microk_bulldozer-2.c
Copyright statement(s): Copyright (c) 2014-2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zscal_microk_haswell-2.c
Copyright statement(s): Copyright (c) 2014-2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zscal_microk_skylakex-2.c
Copyright statement(s): Copyright (c) 2014-2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zscal_microk_steamroller-2.c
Copyright statement(s): Copyright (c) 2014-2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zscal_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zscal_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zscal.c
Copyright statement(s): Copyright (c) 2013 - 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86_64/zscal.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zsum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zswap_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zswap_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zswap.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zsymv_L_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zsymv_L_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zsymv_U_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/zsymv_U_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_LN_2x1_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_LN_2x2_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_LN_2x2_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_LN_2x2_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_LN_2x2_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_LN_2x4_nehalem.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_LN_4x2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_LN_bulldozer.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_LT_1x4_nehalem.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_LT_2x1_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_LT_2x2_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_LT_2x2_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_LT_2x2_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_LT_2x2_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_LT_2x4_nehalem.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_LT_4x2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_LT_bulldozer.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_RN_bulldozer.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_RT_1x4_nehalem.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_RT_2x2_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_RT_2x2_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_RT_2x2_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_RT_2x2_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_RT_2x4_nehalem.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_RT_4x2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86_64/ztrsm_kernel_RT_bulldozer.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/amax_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/amax_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/amax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/asum_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/asum_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/asum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/axpy_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/axpy_sse2_opteron.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/axpy_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/axpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/cabs.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/copy_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/copy_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/copy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/cpuid_win.c
Copyright statement(s): Copyright (c) 2015, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/x86/cpuid.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/dot_amd.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/dot_sse_opteron.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/dot_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/dot_sse2_opteron.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/dot_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/dot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_beta.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_1x4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_2x2_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_2x2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_2x4_3dnow.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_2x4_barcelona.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_2x4_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_2x4_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_2x4_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_2x4_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_4x2_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_4x2_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_4x4_barcelona.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_4x4_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_4x4_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_4x4_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_8x1_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_8x2_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_kernel_8x2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_ncopy_2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_ncopy_2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_ncopy_4_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_tcopy_2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_tcopy_2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemm_tcopy_4_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemv_n_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemv_n_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemv_n_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemv_t_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemv_t_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemv_t_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/gemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/iamax_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/iamax_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/iamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/izamax_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/izamax_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/izamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/lsame.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/nrm2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/nrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/qaxpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/qconjg.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/qdot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/qgemm_kernel_2x2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/qgemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/qgemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/qtrsm_kernel_LN_2x2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/qtrsm_kernel_LT_2x2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/qtrsm_kernel_RT_2x2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/rot_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/rot_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/rot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/scal_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/scal_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/scal.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/staticbuffer.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/sum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/swap_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/swap_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/swap.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LN_2x2_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LN_2x2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LN_2x4_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LN_2x4_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LN_2x4_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LN_4x2_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LN_4x2_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LN_4x4_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LN_4x4_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LN_8x2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LT_1x4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LT_2x2_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LT_2x2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LT_2x4_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LT_2x4_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LT_2x4_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LT_4x2_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LT_4x2_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LT_4x4_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LT_4x4_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_LT_8x2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_RT_1x4.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_RT_2x2_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_RT_2x2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_RT_2x4_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_RT_2x4_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_RT_2x4_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_RT_4x2_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_RT_4x2_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_RT_4x4_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_RT_4x4_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/trsm_kernel_RT_8x2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/xaxpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/xdot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/xgemm_kernel_1x1.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/xgemm3m_kernel_2x2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/xgemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/xgemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/xtrsm_kernel_LT_1x1.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zamax_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zamax_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zamax.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zasum_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zasum_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zasum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zaxpy_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zaxpy_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zaxpy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zcopy_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zcopy_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zcopy.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zdot_amd.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zdot_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zdot_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zdot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_beta.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_kernel_1x1_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_kernel_1x1.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_kernel_1x2_3dnow.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_kernel_1x2_barcelona.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_kernel_1x2_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_kernel_1x2_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_kernel_1x2_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_kernel_1x2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_kernel_2x1_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_kernel_2x1_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_kernel_2x2_barcelona.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_kernel_2x2_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_kernel_2x2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_kernel_2x2_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_kernel_4x1_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_kernel_4x1_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_ncopy_2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm_tcopy_2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm3m_kernel_1x4_athlon.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm3m_kernel_2x2_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm3m_kernel_2x2_coppermine.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm3m_kernel_2x4_barcelona.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm3m_kernel_2x4_opteron.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm3m_kernel_2x4_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm3m_kernel_2x4_prescott.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm3m_kernel_4x2_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm3m_kernel_4x2_northwood.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm3m_kernel_4x4_barcelona.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm3m_kernel_4x4_opteron.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm3m_kernel_4x4_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm3m_kernel_4x4_prescott.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm3m_kernel_8x2_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemm3m_kernel_8x2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemv_n_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemv_n_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemv_n_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemv_n.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemv_t_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemv_t_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemv_t_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zgemv_t.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/znrm2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/znrm2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zrot_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zrot_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zrot.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zscal_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zscal_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zscal.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zsum.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zswap_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zswap_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/zswap.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_LN_2x1_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_LN_2x1_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_LN_2x2_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_LN_2x2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_LN_4x1_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_LT_1x1_atom.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_LT_1x1.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_LT_1x2_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_LT_1x2_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_LT_1x2_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_LT_2x1_core2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_LT_2x1_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_LT_2x2_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_LT_2x2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_LT_4x1_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_RT_1x2_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_RT_1x2_sse2.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_RT_1x2_sse3.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_RT_2x2_penryn.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/x86/ztrsm_kernel_RT_2x2_sse.S
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/kernel/zarch/camax.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/camin.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/casum.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/caxpy.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/ccopy.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/cdot.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/cgemv_n_4.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/cgemv_t_4.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/crot.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/cscal.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/csum.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/cswap.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/ctrmm4x4V.S
Copyright statement(s): c("Copyright (c) 2013-2017, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/zarch/damax_z13.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/damax.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/damin_z13.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/damin.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/dasum.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/daxpy.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/dcopy.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/ddot.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/dgemv_n_4.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/dgemv_t_4.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/dmax_z13.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/dmax.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/dmin_z13.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/dmin.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/drot.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/dscal.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/dsdot.c
Copyright statement(s): Copyright (c) 2013-2019,The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/dsum.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/dswap.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/gemm_vec.c
Copyright statement(s): Copyright (c) IBM Corporation 2020

---------------

File: OpenBLAS/kernel/zarch/gemm8x4V.S
Copyright statement(s): c("Copyright (c) 2013-2017, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/zarch/icamax.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/icamin.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/idamax.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/idamin.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/idmax.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/idmin.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/isamax.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/isamin.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/ismax.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/ismin.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/izamax.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/izamin.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/samax.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/samin.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/sasum.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/saxpy.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/scopy.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/sdot.c
Copyright statement(s): Copyright (c) 2013-2019,The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/sgemv_n_4.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/sgemv_t_4.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/smax.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/smin.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/srot.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/sscal.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/ssum.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/sswap.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/strmm8x4V.S
Copyright statement(s): c("Copyright (c) 2013-2017, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/zarch/trmm8x4V.S
Copyright statement(s): c("Copyright (c) 2013-2017, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/kernel/zarch/vector-common.h
Copyright statement(s): Copyright (c) IBM Corporation 2020

---------------

File: OpenBLAS/kernel/zarch/zamax_z13.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/zamax.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/zamin_z13.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/zamin.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/zasum.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/zaxpy.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/zcopy.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/zdot.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/zgemv_n_4.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/zgemv_t_4.c
Copyright statement(s): Copyright (c) 2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/zrot.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/zscal.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/zsum.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/zswap.c
Copyright statement(s): Copyright (c) 2013-2019, The OpenBLAS Project

---------------

File: OpenBLAS/kernel/zarch/ztrmm4x4V.S
Copyright statement(s): c("Copyright (c) 2013-2017, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/lapack-netlib/CMAKE/CheckFortranTypeSizes.cmake
Copyright statement(s): Chuck Atkins Copyright 2011

---------------

File: OpenBLAS/lapack-netlib/CMAKE/CheckLAPACKCompilerFlags.cmake
Copyright statement(s): Chuck Atkins Copyright 2011

---------------

File: OpenBLAS/lapack-netlib/CMAKE/Findcodecov.cmake
Copyright statement(s): Copyright (c) 2015-2016 RWTH Aachen University, Federal Republic of Germany

---------------

File: OpenBLAS/lapack-netlib/CMAKE/FindGcov.cmake
Copyright statement(s): Copyright (c) 2015-2016 RWTH Aachen University, Federal Republic of Germany

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/include/lapacke_config.h
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/include/lapacke_utils.h
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/include/lapacke.h
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/LICENSE
Copyright statement(s): Copyright (c) 2012, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/Makefile
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/README
Copyright statement(s): Copyright (c) 2011, Intel Corporation

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cbbcsd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cbbcsd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cbdsqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cbdsqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbbrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbbrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbrfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbrfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbsvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbsvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbtrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbtrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbtrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgbtrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgebak_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgebak.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgebal_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgebal.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgebrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgebrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgecon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgecon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgedmd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgedmd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgedmdq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgedmdq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgees_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgees.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeesx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeesx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgehrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgehrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgejsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgejsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgelq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgelq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgelq2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgelq2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgelqf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgelqf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgels_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgels.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgelsd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgelsd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgelss_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgelss.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgelsy_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgelsy.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgemlq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgemlq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgemqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgemqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgemqrt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgemqrt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqlf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqlf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqp3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqp3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqpf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqpf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqr2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqr2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqrfp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqrfp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqrt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqrt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqrt2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqrt2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqrt3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgeqrt3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgerfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgerfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgerfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgerfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgerqf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgerqf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgesdd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgesdd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgesv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgesv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgesvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgesvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgesvdq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgesvdq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgesvdx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgesvdx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgesvj_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgesvj.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgesvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgesvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgesvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgesvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgetf2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgetf2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgetrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgetrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgetrf2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgetrf2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgetri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgetri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgetrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgetrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgetsls_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgetsls.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgetsqrhrt_work.c
Copyright statement(s): Copyright (c) 2020, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgetsqrhrt.c
Copyright statement(s): Copyright (c) 2020, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggbak_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggbak.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggbal_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggbal.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgges_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgges.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgges3_work.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgges3.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggesx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggesx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggev3_work.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggev3.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggglm_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggglm.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgghd3_work.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgghd3.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgghrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgghrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgglse_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgglse.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggqrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggqrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggrqf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggrqf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggsvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggsvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggsvd3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggsvd3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggsvp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggsvp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggsvp3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cggsvp3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgtcon_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgtcon.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgtrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgtrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgtsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgtsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgtsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgtsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgttrf_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgttrf.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgttrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cgttrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbev_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbev_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbevd_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbevd_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbevd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbevd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbevx_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbevx_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbgst_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbgst.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbgv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbgv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbgvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbgvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbgvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbgvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbtrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chbtrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_checon_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_checon_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_checon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_checon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheev_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheev_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheevd_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheevd_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheevd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheevd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheevr_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheevr_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheevr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheevr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheevx_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheevx_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chegst_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chegst.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chegv_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chegv_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chegv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chegv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chegvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chegvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chegvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chegvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cherfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cherfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cherfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cherfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chesv_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chesv_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chesv_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chesv_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chesv_rk_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chesv_rk.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chesv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chesv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chesvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chesvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chesvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chesvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheswapr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cheswapr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrf_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrf_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrf_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrf_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrf_rk_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrf_rk.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrf_rook_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrf_rook.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetri_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetri_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetri2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetri2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetri2x_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetri2x.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrs_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrs_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrs_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrs_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrs_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrs_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrs_rook_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrs_rook.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrs2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chetrs2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chfrk_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chfrk.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chgeqz_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chgeqz.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpevd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpevd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpgst_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpgst.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpgv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpgv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpgvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpgvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpgvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpgvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chprfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chprfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chpsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chptrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chptrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chptrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chptrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chptri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chptri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chptrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chptrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chsein_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chsein.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chseqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_chseqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clacgv_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clacgv.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clacn2_work.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clacn2.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clacp2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clacp2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clacpy_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clacpy.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clacrm_work.c
Copyright statement(s): Copyright (c) 2017, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clacrm.c
Copyright statement(s): Copyright (c) 2017, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clag2z_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clag2z.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clagge_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clagge.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_claghe_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_claghe.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clagsy_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clagsy.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clangb_work.c
Copyright statement(s): Copyright (c) 2022, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clangb.c
Copyright statement(s): Copyright (c) 2022, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clange_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clange.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clanhe_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clanhe.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clansy_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clansy.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clantr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clantr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clapmr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clapmr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clapmt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clapmt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clarcm_work.c
Copyright statement(s): Copyright (c) 2017, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clarcm.c
Copyright statement(s): Copyright (c) 2017, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clarfb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clarfb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clarfg_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clarfg.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clarft_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clarft.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clarfx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clarfx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clarnv_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clarnv.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clascl_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clascl.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_claset_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_claset.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_classq_work.c
Copyright statement(s): Copyright (c) 2017, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_classq.c
Copyright statement(s): Copyright (c) 2017, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_claswp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_claswp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clatms_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clatms.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clauum_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_clauum.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpbcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpbcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpbequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpbequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpbrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpbrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpbstf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpbstf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpbsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpbsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpbsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpbsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpbtrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpbtrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpbtrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpbtrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpftrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpftrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpftri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpftri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpftrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpftrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpocon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpocon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpoequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpoequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpoequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpoequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cporfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cporfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cporfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cporfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cposv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cposv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cposvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cposvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cposvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cposvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpotrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpotrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpotrf2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpotrf2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpotri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpotri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpotrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpotrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cppcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cppcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cppequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cppequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpprfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpprfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cppsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cppsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cppsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cppsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpptrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpptrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpptri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpptri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpptrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpptrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpstrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpstrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cptcon_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cptcon.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpteqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpteqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cptrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cptrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cptsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cptsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cptsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cptsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpttrf_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpttrf.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpttrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cpttrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cspcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cspcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csprfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csprfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cspsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cspsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cspsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cspsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csptrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csptrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csptri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csptri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csptrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csptrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cstedc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cstedc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cstegr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cstegr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cstein_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cstein.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cstemr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cstemr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csteqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csteqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csycon_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csycon_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csycon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csycon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csyconv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csyconv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csyequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csyequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csyr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csyr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csyrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csyrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csyrfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csyrfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csysv_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csysv_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csysv_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csysv_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csysv_rk_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csysv_rk.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csysv_rook_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csysv_rook.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csysv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csysv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csysvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csysvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csysvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csysvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csyswapr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csyswapr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrf_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrf_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrf_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrf_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrf_rk_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrf_rk.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrf_rook_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrf_rook.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytri_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytri_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytri2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytri2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytri2x_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytri2x.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrs_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrs_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrs_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrs_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrs_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrs_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrs_rook_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrs_rook.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrs2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_csytrs2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctbcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctbcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctbrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctbrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctbtrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctbtrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctfsm_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctfsm.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctftri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctftri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctfttp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctfttp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctfttr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctfttr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctgevc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctgevc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctgexc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctgexc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctgsen_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctgsen.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctgsja_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctgsja.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctgsna_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctgsna.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctgsyl_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctgsyl.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctpcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctpcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctpmqrt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctpmqrt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctpqrt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctpqrt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctpqrt2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctpqrt2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctprfb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctprfb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctprfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctprfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctptri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctptri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctptrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctptrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctpttf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctpttf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctpttr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctpttr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrevc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrevc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrexc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrexc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrsen_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrsen.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrsna_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrsna.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrsyl_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrsyl.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrtri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrtri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrtrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrtrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrttf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrttf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrttp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctrttp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctzrzf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ctzrzf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunbdb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunbdb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cuncsd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cuncsd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cuncsd2by1_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cuncsd2by1.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cungbr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cungbr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunghr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunghr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunglq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunglq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cungql_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cungql.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cungqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cungqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cungrq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cungrq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cungtr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cungtr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cungtsqr_row_work.c
Copyright statement(s): Copyright (c) 2020, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cungtsqr_row.c
Copyright statement(s): Copyright (c) 2020, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunmbr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunmbr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunmhr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunmhr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunmlq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunmlq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunmql_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunmql.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunmqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunmqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunmrq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunmrq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunmrz_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunmrz.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunmtr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cunmtr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cupgtr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cupgtr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cupmtr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_cupmtr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dbbcsd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dbbcsd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dbdsdc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dbdsdc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dbdsqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dbdsqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dbdsvdx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dbdsvdx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ddisna_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ddisna.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbbrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbbrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbrfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbrfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbsvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbsvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbtrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbtrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbtrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgbtrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgebak_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgebak.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgebal_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgebal.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgebrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgebrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgecon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgecon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgedmd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgedmd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgedmdq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgedmdq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgees_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgees.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeesx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeesx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgehrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgehrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgejsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgejsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgelq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgelq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgelq2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgelq2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgelqf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgelqf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgels_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgels.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgelsd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgelsd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgelss_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgelss.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgelsy_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgelsy.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgemlq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgemlq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgemqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgemqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgemqrt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgemqrt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqlf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqlf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqp3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqp3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqpf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqpf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqr2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqr2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqrfp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqrfp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqrt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqrt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqrt2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqrt2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqrt3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgeqrt3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgerfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgerfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgerfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgerfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgerqf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgerqf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgesdd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgesdd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgesv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgesv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgesvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgesvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgesvdq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgesvdq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgesvdx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgesvdx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgesvj_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgesvj.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgesvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgesvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgesvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgesvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgetf2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgetf2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgetrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgetrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgetrf2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgetrf2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgetri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgetri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgetrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgetrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgetsls_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgetsls.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgetsqrhrt_work.c
Copyright statement(s): Copyright (c) 2020, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgetsqrhrt.c
Copyright statement(s): Copyright (c) 2020, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggbak_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggbak.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggbal_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggbal.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgges_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgges.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgges3_work.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgges3.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggesx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggesx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggev3_work.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggev3.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggglm_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggglm.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgghd3_work.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgghd3.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgghrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgghrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgglse_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgglse.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggqrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggqrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggrqf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggrqf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggsvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggsvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggsvd3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggsvd3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggsvp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggsvp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggsvp3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dggsvp3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgtcon_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgtcon.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgtrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgtrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgtsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgtsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgtsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgtsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgttrf_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgttrf.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgttrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dgttrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dhgeqz_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dhgeqz.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dhsein_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dhsein.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dhseqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dhseqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlacn2_work.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlacn2.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlacpy_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlacpy.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlag2s_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlag2s.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlagge_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlagge.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlagsy_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlagsy.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlamch_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlamch.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlangb_work.c
Copyright statement(s): Copyright (c) 2022, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlangb.c
Copyright statement(s): Copyright (c) 2022, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlange_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlange.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlansy_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlansy.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlantr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlantr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlapmr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlapmr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlapmt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlapmt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlapy2_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlapy2.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlapy3_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlapy3.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlarfb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlarfb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlarfg_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlarfg.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlarft_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlarft.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlarfx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlarfx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlarnv_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlarnv.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlartgp_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlartgp.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlartgs_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlartgs.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlascl_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlascl.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlaset_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlaset.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlasrt_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlasrt.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlassq_work.c
Copyright statement(s): Copyright (c) 2017, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlassq.c
Copyright statement(s): Copyright (c) 2017, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlaswp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlaswp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlatms_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlatms.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlauum_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dlauum.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dopgtr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dopgtr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dopmtr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dopmtr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorbdb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorbdb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorcsd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorcsd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorcsd2by1_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorcsd2by1.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorgbr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorgbr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorghr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorghr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorglq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorglq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorgql_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorgql.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorgqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorgqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorgrq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorgrq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorgtr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorgtr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorgtsqr_row_work.c
Copyright statement(s): Copyright (c) 2020, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dorgtsqr_row.c
Copyright statement(s): Copyright (c) 2020, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dormbr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dormbr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dormhr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dormhr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dormlq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dormlq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dormql_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dormql.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dormqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dormqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dormrq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dormrq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dormrz_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dormrz.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dormtr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dormtr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpbcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpbcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpbequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpbequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpbrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpbrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpbstf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpbstf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpbsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpbsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpbsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpbsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpbtrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpbtrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpbtrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpbtrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpftrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpftrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpftri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpftri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpftrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpftrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpocon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpocon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpoequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpoequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpoequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpoequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dporfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dporfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dporfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dporfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dposv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dposv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dposvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dposvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dposvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dposvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpotrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpotrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpotrf2_work.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpotrf2.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpotri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpotri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpotrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpotrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dppcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dppcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dppequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dppequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpprfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpprfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dppsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dppsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dppsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dppsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpptrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpptrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpptri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpptri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpptrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpptrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpstrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpstrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dptcon_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dptcon.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpteqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpteqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dptrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dptrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dptsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dptsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dptsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dptsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpttrf_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpttrf.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpttrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dpttrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbev_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbev_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbevd_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbevd_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbevd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbevd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbevx_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbevx_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbgst_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbgst.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbgv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbgv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbgvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbgvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbgvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbgvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbtrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsbtrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsfrk_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsfrk.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsgesv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsgesv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspevd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspevd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspgst_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspgst.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspgv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspgv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspgvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspgvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspgvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspgvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsposv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsposv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsprfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsprfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dspsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsptrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsptrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsptrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsptrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsptri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsptri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsptrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsptrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstebz_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstebz.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstedc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstedc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstegr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstegr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstein_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstein.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstemr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstemr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsteqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsteqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsterf_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsterf.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstevd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstevd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstevr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstevr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dstevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsycon_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsycon_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsycon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsycon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyconv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyconv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyev_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyev_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyevd_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyevd_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyevd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyevd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyevr_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyevr_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyevr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyevr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyevx_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyevx_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsygst_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsygst.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsygv_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsygv_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsygv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsygv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsygvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsygvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsygvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsygvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyrfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyrfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsysv_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsysv_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsysv_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsysv_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsysv_rk_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsysv_rk.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsysv_rook_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsysv_rook.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsysv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsysv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsysvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsysvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsysvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsysvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyswapr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsyswapr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrf_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrf_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrf_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrf_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrf_rk_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrf_rk.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrf_rook_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrf_rook.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytri_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytri_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytri2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytri2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytri2x_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytri2x.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrs_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrs_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrs_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrs_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrs_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrs_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrs_rook_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrs_rook.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrs2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dsytrs2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtbcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtbcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtbrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtbrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtbtrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtbtrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtfsm_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtfsm.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtftri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtftri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtfttp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtfttp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtfttr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtfttr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtgevc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtgevc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtgexc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtgexc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtgsen_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtgsen.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtgsja_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtgsja.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtgsna_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtgsna.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtgsyl_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtgsyl.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtpcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtpcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtpmqrt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtpmqrt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtpqrt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtpqrt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtpqrt2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtpqrt2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtprfb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtprfb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtprfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtprfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtptri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtptri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtptrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtptrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtpttf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtpttf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtpttr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtpttr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrevc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrevc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrexc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrexc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrsen_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrsen.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrsna_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrsna.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrsyl_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrsyl.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrtri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrtri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrtrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrtrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrttf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrttf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrttp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtrttp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtzrzf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_dtzrzf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ilaver.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_nancheck.c
Copyright statement(s): Copyright (c) 2017, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sbbcsd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sbbcsd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sbdsdc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sbdsdc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sbdsqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sbdsqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sbdsvdx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sbdsvdx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sdisna_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sdisna.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbbrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbbrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbrfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbrfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbsvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbsvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbtrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbtrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbtrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgbtrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgebak_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgebak.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgebal_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgebal.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgebrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgebrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgecon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgecon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgedmd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgedmd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgedmdq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgedmdq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgees_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgees.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeesx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeesx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgehrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgehrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgejsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgejsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgelq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgelq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgelq2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgelq2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgelqf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgelqf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgels_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgels.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgelsd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgelsd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgelss_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgelss.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgelsy_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgelsy.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgemlq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgemlq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgemqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgemqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgemqrt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgemqrt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqlf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqlf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqp3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqp3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqpf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqpf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqr2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqr2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqrfp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqrfp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqrt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqrt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqrt2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqrt2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqrt3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgeqrt3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgerfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgerfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgerfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgerfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgerqf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgerqf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgesdd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgesdd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgesv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgesv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgesvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgesvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgesvdq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgesvdq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgesvdx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgesvdx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgesvj_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgesvj.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgesvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgesvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgesvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgesvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgetf2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgetf2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgetrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgetrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgetrf2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgetrf2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgetri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgetri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgetrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgetrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgetsls_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgetsls.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgetsqrhrt_work.c
Copyright statement(s): Copyright (c) 2020, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgetsqrhrt.c
Copyright statement(s): Copyright (c) 2020, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggbak_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggbak.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggbal_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggbal.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgges_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgges.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgges3_work.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgges3.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggesx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggesx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggev3_work.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggev3.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggglm_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggglm.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgghd3_work.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgghd3.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgghrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgghrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgglse_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgglse.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggqrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggqrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggrqf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggrqf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggsvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggsvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggsvd3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggsvd3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggsvp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggsvp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggsvp3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sggsvp3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgtcon_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgtcon.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgtrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgtrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgtsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgtsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgtsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgtsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgttrf_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgttrf.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgttrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sgttrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_shgeqz_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_shgeqz.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_shsein_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_shsein.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_shseqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_shseqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slacn2_work.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slacn2.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slacpy_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slacpy.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slag2d_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slag2d.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slagge_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slagge.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slagsy_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slagsy.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slamch_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slamch.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slangb_work.c
Copyright statement(s): Copyright (c) 2022, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slangb.c
Copyright statement(s): Copyright (c) 2022, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slange_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slange.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slansy_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slansy.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slantr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slantr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slapmr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slapmr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slapmt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slapmt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slapy2_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slapy2.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slapy3_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slapy3.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slarfb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slarfb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slarfg_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slarfg.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slarft_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slarft.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slarfx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slarfx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slarnv_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slarnv.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slartgp_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slartgp.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slartgs_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slartgs.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slascl_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slascl.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slaset_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slaset.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slasrt_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slasrt.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slassq_work.c
Copyright statement(s): Copyright (c) 2017, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slassq.c
Copyright statement(s): Copyright (c) 2017, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slaswp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slaswp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slatms_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slatms.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slauum_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_slauum.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sopgtr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sopgtr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sopmtr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sopmtr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorbdb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorbdb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorcsd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorcsd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorcsd2by1_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorcsd2by1.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorgbr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorgbr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorghr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorghr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorglq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorglq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorgql_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorgql.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorgqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorgqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorgrq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorgrq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorgtr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorgtr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorgtsqr_row_work.c
Copyright statement(s): Copyright (c) 2020, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sorgtsqr_row.c
Copyright statement(s): Copyright (c) 2020, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sormbr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sormbr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sormhr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sormhr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sormlq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sormlq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sormql_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sormql.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sormqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sormqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sormrq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sormrq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sormrz_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sormrz.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sormtr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sormtr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spbcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spbcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spbequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spbequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spbrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spbrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spbstf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spbstf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spbsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spbsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spbsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spbsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spbtrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spbtrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spbtrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spbtrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spftrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spftrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spftri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spftri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spftrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spftrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spocon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spocon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spoequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spoequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spoequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spoequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sporfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sporfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sporfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sporfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sposv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sposv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sposvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sposvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sposvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sposvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spotrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spotrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spotrf2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spotrf2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spotri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spotri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spotrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spotrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sppcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sppcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sppequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sppequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spprfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spprfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sppsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sppsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sppsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sppsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spptrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spptrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spptri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spptri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spptrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spptrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spstrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spstrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sptcon_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sptcon.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spteqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spteqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sptrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sptrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sptsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sptsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sptsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sptsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spttrf_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spttrf.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spttrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_spttrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbev_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbev_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbevd_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbevd_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbevd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbevd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbevx_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbevx_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbgst_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbgst.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbgv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbgv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbgvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbgvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbgvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbgvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbtrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssbtrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssfrk_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssfrk.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspevd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspevd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspgst_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspgst.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspgv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspgv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspgvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspgvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspgvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspgvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssprfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssprfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sspsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssptrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssptrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssptrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssptrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssptri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssptri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssptrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssptrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstebz_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstebz.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstedc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstedc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstegr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstegr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstein_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstein.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstemr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstemr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssteqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssteqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssterf_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssterf.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstevd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstevd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstevr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstevr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_sstevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssycon_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssycon_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssycon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssycon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyconv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyconv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyev_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyev_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyevd_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyevd_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyevd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyevd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyevr_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyevr_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyevr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyevr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyevx_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyevx_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssygst_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssygst.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssygv_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssygv_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssygv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssygv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssygvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssygvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssygvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssygvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyrfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyrfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssysv_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssysv_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssysv_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssysv_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssysv_rk_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssysv_rk.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssysv_rook_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssysv_rook.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssysv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssysv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssysvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssysvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssysvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssysvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyswapr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssyswapr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrf_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrf_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrf_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrf_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrf_rk_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrf_rk.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrf_rook_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrf_rook.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytri_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytri_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytri2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytri2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytri2x_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytri2x.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrs_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrs_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrs_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrs_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrs_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrs_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrs_rook_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrs_rook.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrs2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ssytrs2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stbcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stbcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stbrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stbrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stbtrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stbtrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stfsm_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stfsm.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stftri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stftri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stfttp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stfttp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stfttr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stfttr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stgevc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stgevc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stgexc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stgexc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stgsen_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stgsen.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stgsja_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stgsja.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stgsna_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stgsna.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stgsyl_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stgsyl.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stpcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stpcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stpmqrt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stpmqrt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stpqrt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stpqrt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stpqrt2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stpqrt2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stprfb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stprfb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stprfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stprfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stptri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stptri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stptrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stptrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stpttf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stpttf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stpttr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stpttr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strevc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strevc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strexc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strexc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strsen_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strsen.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strsna_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strsna.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strsyl_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strsyl.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strtri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strtri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strtrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strtrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strttf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strttf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strttp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_strttp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stzrzf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_stzrzf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zbbcsd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zbbcsd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zbdsqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zbdsqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zcgesv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zcgesv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zcposv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zcposv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbbrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbbrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbrfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbrfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbsvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbsvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbtrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbtrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbtrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgbtrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgebak_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgebak.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgebal_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgebal.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgebrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgebrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgecon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgecon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgedmd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgedmd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgedmdq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgedmdq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgees_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgees.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeesx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeesx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgehrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgehrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgejsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgejsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgelq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgelq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgelq2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgelq2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgelqf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgelqf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgels_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgels.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgelsd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgelsd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgelss_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgelss.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgelsy_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgelsy.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgemlq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgemlq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgemqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgemqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgemqrt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgemqrt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqlf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqlf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqp3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqp3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqpf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqpf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqr2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqr2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqrfp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqrfp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqrt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqrt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqrt2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqrt2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqrt3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgeqrt3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgerfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgerfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgerfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgerfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgerqf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgerqf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgesdd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgesdd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgesv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgesv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgesvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgesvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgesvdq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgesvdq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgesvdx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgesvdx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgesvj_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgesvj.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgesvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgesvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgesvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgesvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgetf2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgetf2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgetrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgetrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgetrf2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgetrf2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgetri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgetri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgetrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgetrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgetsls_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgetsls.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgetsqrhrt_work.c
Copyright statement(s): Copyright (c) 2020, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgetsqrhrt.c
Copyright statement(s): Copyright (c) 2020, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggbak_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggbak.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggbal_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggbal.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgges_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgges.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgges3_work.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgges3.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggesx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggesx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggev3_work.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggev3.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggglm_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggglm.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgghd3_work.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgghd3.c
Copyright statement(s): Copyright (c) 2015, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgghrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgghrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgglse_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgglse.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggqrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggqrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggrqf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggrqf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggsvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggsvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggsvd3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggsvd3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggsvp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggsvp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggsvp3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zggsvp3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgtcon_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgtcon.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgtrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgtrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgtsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgtsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgtsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgtsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgttrf_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgttrf.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgttrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zgttrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbev_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbev_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbevd_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbevd_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbevd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbevd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbevx_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbevx_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbgst_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbgst.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbgv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbgv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbgvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbgvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbgvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbgvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbtrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhbtrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhecon_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhecon_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhecon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhecon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheev_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheev_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheevd_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheevd_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheevd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheevd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheevr_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheevr_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheevr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheevr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheevx_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheevx_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhegst_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhegst.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhegv_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhegv_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhegv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhegv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhegvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhegvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhegvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhegvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zherfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zherfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zherfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zherfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhesv_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhesv_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhesv_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhesv_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhesv_rk_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhesv_rk.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhesv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhesv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhesvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhesvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhesvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhesvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheswapr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zheswapr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrf_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrf_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrf_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrf_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrf_rk_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrf_rk.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrf_rook_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrf_rook.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetri_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetri_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetri2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetri2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetri2x_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetri2x.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrs_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrs_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrs_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrs_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrs_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrs_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrs_rook_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrs_rook.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrs2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhetrs2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhfrk_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhfrk.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhgeqz_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhgeqz.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpev_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpev.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpevd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpevd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpevx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpevx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpgst_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpgst.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpgv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpgv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpgvd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpgvd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpgvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpgvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhprfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhprfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhpsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhptrd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhptrd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhptrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhptrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhptri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhptri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhptrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhptrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhsein_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhsein.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhseqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zhseqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlacgv_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlacgv.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlacn2_work.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlacn2.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlacp2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlacp2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlacpy_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlacpy.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlacrm_work.c
Copyright statement(s): Copyright (c) 2017, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlacrm.c
Copyright statement(s): Copyright (c) 2017, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlag2c_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlag2c.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlagge_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlagge.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlaghe_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlaghe.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlagsy_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlagsy.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlangb_work.c
Copyright statement(s): Copyright (c) 2022, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlangb.c
Copyright statement(s): Copyright (c) 2022, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlange_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlange.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlanhe_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlanhe.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlansy_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlansy.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlantr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlantr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlapmr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlapmr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlapmt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlapmt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlarcm_work.c
Copyright statement(s): Copyright (c) 2017, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlarcm.c
Copyright statement(s): Copyright (c) 2017, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlarfb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlarfb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlarfg_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlarfg.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlarft_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlarft.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlarfx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlarfx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlarnv_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlarnv.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlascl_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlascl.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlaset_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlaset.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlassq_work.c
Copyright statement(s): Copyright (c) 2017, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlassq.c
Copyright statement(s): Copyright (c) 2017, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlaswp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlaswp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlatms_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlatms.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlauum_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zlauum.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpbcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpbcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpbequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpbequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpbrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpbrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpbstf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpbstf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpbsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpbsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpbsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpbsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpbtrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpbtrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpbtrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpbtrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpftrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpftrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpftri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpftri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpftrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpftrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpocon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpocon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpoequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpoequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpoequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpoequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zporfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zporfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zporfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zporfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zposv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zposv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zposvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zposvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zposvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zposvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpotrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpotrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpotrf2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpotrf2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpotri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpotri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpotrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpotrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zppcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zppcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zppequ_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zppequ.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpprfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpprfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zppsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zppsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zppsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zppsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpptrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpptrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpptri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpptri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpptrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpptrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpstrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpstrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zptcon_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zptcon.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpteqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpteqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zptrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zptrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zptsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zptsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zptsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zptsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpttrf_work.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpttrf.c
Copyright statement(s): Copyright (c) 2011, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpttrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zpttrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zspcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zspcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsprfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsprfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zspsv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zspsv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zspsvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zspsvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsptrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsptrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsptri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsptri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsptrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsptrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zstedc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zstedc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zstegr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zstegr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zstein_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zstein.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zstemr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zstemr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsteqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsteqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsycon_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsycon_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsycon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsycon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsyconv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsyconv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsyequb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsyequb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsyr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsyr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsyrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsyrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsyrfsx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsyrfsx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsysv_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsysv_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsysv_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsysv_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsysv_rk_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsysv_rk.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsysv_rook_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsysv_rook.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsysv_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsysv.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsysvx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsysvx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsysvxx_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsysvxx.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsyswapr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsyswapr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrf_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrf_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrf_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrf_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrf_rk_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrf_rk.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrf_rook_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrf_rook.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytri_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytri_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytri2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytri2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytri2x_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytri2x.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrs_3_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrs_3.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrs_aa_2stage_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrs_aa_2stage.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrs_aa_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrs_aa.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrs_rook_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrs_rook.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrs2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zsytrs2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztbcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztbcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztbrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztbrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztbtrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztbtrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztfsm_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztfsm.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztftri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztftri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztfttp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztfttp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztfttr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztfttr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztgevc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztgevc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztgexc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztgexc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztgsen_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztgsen.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztgsja_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztgsja.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztgsna_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztgsna.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztgsyl_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztgsyl.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztpcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztpcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztpmqrt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztpmqrt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztpqrt_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztpqrt.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztpqrt2_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztpqrt2.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztprfb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztprfb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztprfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztprfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztptri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztptri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztptrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztptrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztpttf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztpttf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztpttr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztpttr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrcon_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrcon.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrevc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrevc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrexc_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrexc.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrrfs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrrfs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrsen_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrsen.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrsna_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrsna.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrsyl_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrsyl.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrtri_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrtri.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrtrs_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrtrs.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrttf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrttf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrttp_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztrttp.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztzrzf_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_ztzrzf.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunbdb_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunbdb.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zuncsd_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zuncsd.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zuncsd2by1_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zuncsd2by1.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zungbr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zungbr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunghr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunghr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunglq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunglq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zungql_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zungql.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zungqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zungqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zungrq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zungrq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zungtr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zungtr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zungtsqr_row_work.c
Copyright statement(s): Copyright (c) 2020, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zungtsqr_row.c
Copyright statement(s): Copyright (c) 2020, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunmbr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunmbr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunmhr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunmhr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunmlq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunmlq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunmql_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunmql.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunmqr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunmqr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunmrq_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunmrq.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunmrz_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunmrz.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunmtr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zunmtr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zupgtr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zupgtr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zupmtr_work.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/lapacke_zupmtr.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/src/Makefile
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_c_nancheck.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_cgb_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_cgb_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_cge_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_cge_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_cgg_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_cgg_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_cgt_nancheck.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_chb_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_chb_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_che_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_che_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_chp_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_chp_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_chs_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_chs_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_cpb_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_cpb_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_cpf_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_cpf_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_cpo_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_cpo_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_cpp_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_cpp_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_cpt_nancheck.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_csp_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_csp_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_cst_nancheck.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_csy_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_csy_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ctb_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ctb_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ctf_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ctf_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ctp_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ctp_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ctr_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ctr_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ctz_nancheck.c
Copyright statement(s): Copyright (c) 2022, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ctz_trans.c
Copyright statement(s): Copyright (c) 2022, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_d_nancheck.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dgb_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dgb_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dge_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dge_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dgg_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dgg_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dgt_nancheck.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dhs_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dhs_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dpb_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dpb_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dpf_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dpf_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dpo_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dpo_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dpp_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dpp_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dpt_nancheck.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dsb_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dsb_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dsp_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dsp_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dst_nancheck.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dsy_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dsy_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dtb_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dtb_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dtf_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dtf_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dtp_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dtp_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dtr_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dtr_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dtz_nancheck.c
Copyright statement(s): Copyright (c) 2022, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_dtz_trans.c
Copyright statement(s): Copyright (c) 2022, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_lsame.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_make_complex_double.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_make_complex_float.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_s_nancheck.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_sgb_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_sgb_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_sge_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_sge_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_sgg_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_sgg_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_sgt_nancheck.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_shs_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_shs_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_spb_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_spb_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_spf_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_spf_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_spo_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_spo_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_spp_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_spp_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_spt_nancheck.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ssb_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ssb_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ssp_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ssp_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_sst_nancheck.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ssy_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ssy_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_stb_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_stb_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_stf_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_stf_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_stp_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_stp_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_str_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_str_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_stz_nancheck.c
Copyright statement(s): Copyright (c) 2022, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_stz_trans.c
Copyright statement(s): Copyright (c) 2022, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_xerbla.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_z_nancheck.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zgb_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zgb_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zge_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zge_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zgg_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zgg_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zgt_nancheck.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zhb_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zhb_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zhe_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zhe_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zhp_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zhp_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zhs_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zhs_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zpb_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zpb_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zpf_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zpf_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zpo_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zpo_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zpp_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zpp_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zpt_nancheck.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zsp_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zsp_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zst_nancheck.c
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zsy_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_zsy_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ztb_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ztb_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ztf_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ztf_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ztp_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ztp_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ztr_nancheck.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ztr_trans.c
Copyright statement(s): Copyright (c) 2014, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ztz_nancheck.c
Copyright statement(s): Copyright (c) 2022, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/lapacke_ztz_trans.c
Copyright statement(s): Copyright (c) 2022, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LAPACKE/utils/Makefile
Copyright statement(s): Copyright (c) 2010, Intel Corp.

---------------

File: OpenBLAS/lapack-netlib/LICENSE
Copyright statement(s): c("Copyright (c) 1992-2017 The University of Tennessee and The University of Tennessee Research Foundation", "Copyright (c) 2000-2017 The University of California Berkeley", "Copyright (c) 2006-2017 The University of Colorado Denver")

---------------

File: OpenBLAS/lapack-netlib/README.md
Copyright statement(s): character(0)

---------------

File: OpenBLAS/lapack-netlib/SRC/ctrsen.c
Copyright statement(s): (c) by the reciprocal

---------------

File: OpenBLAS/lapack-netlib/SRC/ctrsen.f
Copyright statement(s): (c) by the reciprocal

---------------

File: OpenBLAS/lapack-netlib/SRC/dtrsen.c
Copyright statement(s): (c) by the reciprocal

---------------

File: OpenBLAS/lapack-netlib/SRC/dtrsen.f
Copyright statement(s): (c) by the reciprocal

---------------

File: OpenBLAS/lapack-netlib/SRC/strsen.c
Copyright statement(s): (c) by the reciprocal

---------------

File: OpenBLAS/lapack-netlib/SRC/strsen.f
Copyright statement(s): (c) by the reciprocal

---------------

File: OpenBLAS/lapack-netlib/SRC/ztrsen.c
Copyright statement(s): (c) by the reciprocal

---------------

File: OpenBLAS/lapack-netlib/SRC/ztrsen.f
Copyright statement(s): (c) by the reciprocal

---------------

File: OpenBLAS/lapack/getf2/getf2_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/getf2/zgetf2_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/getrf/getrf_parallel_omp.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/getrf/getrf_parallel.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/getrf/getrf_single.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/getrs/getrs_parallel.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/getrs/getrs_single.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/getrs/zgetrs_parallel.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/getrs/zgetrs_single.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/laswp/generic/laswp_k_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/laswp/generic/laswp_k_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/laswp/generic/laswp_k_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/laswp/generic/laswp_k_8.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/laswp/generic/laswp_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/laswp/generic/zlaswp_k_1.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/laswp/generic/zlaswp_k_2.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/laswp/generic/zlaswp_k_4.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/laswp/generic/zlaswp_k.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/lauu2/lauu2_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/lauu2/lauu2_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/lauu2/zlauu2_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/lauu2/zlauu2_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/lauum/lauum_L_parallel.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/lauum/lauum_L_single.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/lauum/lauum_U_parallel.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/lauum/lauum_U_single.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/potf2/potf2_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/potf2/potf2_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/potf2/zpotf2_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/potf2/zpotf2_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/potrf/potrf_L_parallel.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/potrf/potrf_L_single.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/potrf/potrf_parallel.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/potrf/potrf_U_parallel.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/potrf/potrf_U_single.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/trti2/trti2_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/trti2/trti2_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/trti2/ztrti2_L.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/trti2/ztrti2_U.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/trtri/trtri_L_parallel.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/trtri/trtri_L_single.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/lapack/trtri/trtri_U_parallel.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/trtri/trtri_U_single.c
Copyright statement(s): Copyright (c) 2013, The OpenBLAS Project

---------------

File: OpenBLAS/lapack/trtrs/trtrs_parallel.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/trtrs/trtrs_single.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/trtrs/ztrtrs_parallel.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/lapack/trtrs/ztrtrs_single.c
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/LICENSE
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/param.h
Copyright statement(s): c("Copyright (c) 2011-2023, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")

---------------

File: OpenBLAS/reference/LICENSE
Copyright statement(s): character(0)

---------------

File: OpenBLAS/relapack/LICENSE
Copyright statement(s): Copyright (c) 2016 Elmar Peise

---------------

File: OpenBLAS/symcopy.h
Copyright statement(s): Copyright 2009, 2010 The University of Texas at Austin

---------------

File: OpenBLAS/test/compare_sgemm_sbgemm.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/test/LICENSE
Copyright statement(s): character(0)

---------------

File: OpenBLAS/utest/ctest.h
Copyright statement(s): Copyright 2011-2016 Bas van den Berg

---------------

File: OpenBLAS/utest/openblas_utest.h
Copyright statement(s): Copyright (c) 2011-2016, The OpenBLAS Project

---------------

File: OpenBLAS/utest/test_amax.c
Copyright statement(s): Copyright (c) 2011-2016, The OpenBLAS Project

---------------

File: OpenBLAS/utest/test_axpy.c
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/utest/test_dnrm2.c
Copyright statement(s): Copyright (c) 2011-2022, The OpenBLAS Project

---------------

File: OpenBLAS/utest/test_dotu.c
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/utest/test_dsdot.c
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/utest/test_fork.c
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/utest/test_ismin.c
Copyright statement(s): Copyright (c) 2020, The OpenBLAS Project

---------------

File: OpenBLAS/utest/test_min.c
Copyright statement(s): Copyright (c) 2011-2016, The OpenBLAS Project

---------------

File: OpenBLAS/utest/test_post_fork.c
Copyright statement(s): Copyright (c) 2011-2020, The OpenBLAS Project

---------------

File: OpenBLAS/utest/test_potrs.c
Copyright statement(s): Copyright (c) 2011-2016, The OpenBLAS Project

---------------

File: OpenBLAS/utest/test_rot.c
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/utest/test_rotmg.c
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/utest/test_swap.c
Copyright statement(s): Copyright (c) 2011-2014, The OpenBLAS Project

---------------

File: OpenBLAS/utest/utest_main.c
Copyright statement(s): Copyright (c) 2011-2016, The OpenBLAS Project

---------------

File: OpenBLAS/utest/utest_main2.c
Copyright statement(s): Copyright (c) 2011-2016, The OpenBLAS Project

---------------

File: OpenBLAS/version.h
Copyright statement(s): c("Copyright (c) 2011-2014, The OpenBLAS Project", "Copyright 2009, 2010 The University of Texas at Austin")
