# Overview

This software contains a number of open source components. For a summary, see 
below. For the relevant licence texts, see Appendix A. For the relevant notices 
and attributions et cetera, see Appendix B.

Not all components listed may be incorporated in, or may necessarily have 
generated derivative works which are incorporated in the firmware, but were 
used during the build process.

Where a range of dates is given after a copyright notice, this should be taken 
to imply that copyright is asserted for every year within that range, inclusive 
of the years stated.

## Components and Licences

OpenBlas - BSD-3-Clause

